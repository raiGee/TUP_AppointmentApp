from django.apps import AppConfig


class OnlineappointmentappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'OnlineAppointmentApp'
